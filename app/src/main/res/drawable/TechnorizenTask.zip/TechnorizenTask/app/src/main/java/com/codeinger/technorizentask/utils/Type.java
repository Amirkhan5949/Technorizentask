package com.codeinger.technorizentask.utils;

public enum Type {
    ADD,UPDATE

}
